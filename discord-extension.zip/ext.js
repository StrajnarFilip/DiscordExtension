"use strict";
console.log("Extension works.");
